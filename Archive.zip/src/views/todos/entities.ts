export interface ITodoItem {
    title: string;
    body: string;
    id: number;
};
